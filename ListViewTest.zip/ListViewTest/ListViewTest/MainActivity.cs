﻿using Android.App;
using Android.Widget;
using Android.OS;
using Android.Views;

namespace ListViewTest
{
    [Activity(Label = "ListViewTest", MainLauncher = true)]
    public class MainActivity : ListActivity
    {
        string[] items;
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);
            items = new string[] { "Vegetables","Fruits","Flower Buds",
                         "Legumes","Bulbs","Tubers" };
            ListAdapter = new ArrayAdapter(this,
                                    Android.Resource.Layout.SimpleListItem1, items);
        }

        protected override void OnListItemClick(ListView l, View v, int position, long id)
        {
            base.OnListItemClick(l, v, position, id);

            //two methods of showing a message to user
            //pop up dialog box or toast.
            // notice the use of "Toast" to display an alert in Android
            //for at home if we want people to test it we have to 
            //download TestFlight to download Xamarin flight at
            //otherwise you can do it on your phone. 
            Toast.MakeText(this, items[position], ToastLength.Short).Show();
        }
    }
}

